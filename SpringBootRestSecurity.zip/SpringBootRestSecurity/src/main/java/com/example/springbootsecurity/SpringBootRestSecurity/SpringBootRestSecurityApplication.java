package com.example.springbootsecurity.SpringBootRestSecurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootRestSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRestSecurityApplication.class, args);
	}

}
