package com.example.springbootsecurity.SpringBootRestSecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootRestSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
